export interface IPeople {
    firstName: string,
    lastName: string,
    bio: string
    favoriteMovies: string[]
}