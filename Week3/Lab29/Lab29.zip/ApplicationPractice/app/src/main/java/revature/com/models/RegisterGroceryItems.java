package revature.com.models;

public class RegisterGroceryItems {
    public String name;
    public double price;

    public RegisterGroceryItems(){

    }
    public RegisterGroceryItems(String name, double price){
        this.name = name;
        this.price = price;
    }
}
